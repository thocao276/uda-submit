#!/bin/bash
#
# TO-DO: run the follwing command and observe the JSON output: 
# airflow connections get aws_credentials -o json 
# 
# [
#     {
#         "id": "67",
#         "conn_id": "aws_credentials",
#         "conn_type": "aws",
#         "description": "",
#         "host": "",
#         "schema": "",
#         "login": "AKIAWNCCOUASS2G3XWHC",
#         "password": "JpFNgb49eWQuOkS1B9ds+taQVZLnX9r7RyzvcUYr",
#         "port": null,
#         "is_encrypted": "True",
#         "is_extra_encrypted": "True",
#         "extra_dejson": {},
#         "get_uri": "aws://AKIAWNCCOUASS2G3XWHC:JpFNgb49eWQuOkS1B9ds%2BtaQVZLnX9r7RyzvcUYr@"
#     }
# ]
#
# Copy the value after "get_uri":
#
# For example: aws://AKIA4QE4NTH3R7EBEANN:s73eJIJRbnqRtll0%2FYKxyVYgrDWXfoRpJCDkcG2m@
#
# TO-DO: Update the following command with the URI and un-comment it:
#
airflow connections add aws_credentials --conn-uri 'aws://AKIAWNCCOUASS2G3XWHC:JpFNgb49eWQuOkS1B9ds%2BtaQVZLnX9r7RyzvcUYr@'
#
#
# TO-DO: run the follwing command and observe the JSON output: 
# airflow connections get redshift -o json
# redshift-thocn.cm6wkpiethl5.us-east-1.redshift.amazonaws.com:5439/dev
# [
#   {
#     "id": "68",
#     "conn_id": "redshift",
#     "conn_type": "redshift",
#     "description": "",
#     "host": "redshift-thocn.cm6wkpiethl5.us-east-1.redshift.amazonaws.com",
#     "schema": "dev",
#     "login": "thodb",
#     "password": "ZXCvbnm123",
#     "port": "5439",
#     "is_encrypted": "True",
#     "is_extra_encrypted": "True",
#     "extra_dejson": {},
#     "get_uri": "redshift://thodb:ZXCvbnm123@redshift-thocn.cm6wkpiethl5.us-east-1.redshift.amazonaws.com:5439/dev"
#   }
# ]

# Copy the value after "get_uri":
#
# For example: redshift://awsuser:R3dsh1ft@default.859321506295.us-east-1.redshift-serverless.amazonaws.com:5439/dev
#
# TO-DO: Update the following command with the URI and un-comment it:
#
airflow connections add redshift --conn-uri 'redshift://thodb:ZXCvbnm123@redshift-thocn.cm6wkpiethl5.us-east-1.redshift.amazonaws.com:5439/dev'
#
# TO-DO: update the following bucket name to match the name of your S3 bucket and un-comment it:
#
airflow variables set s3_bucket thocn-bucket
#
# TO-DO: un-comment the below line:
#
airflow variables set s3_prefix data-pipelines