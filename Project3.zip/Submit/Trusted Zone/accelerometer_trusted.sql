CREATE EXTERNAL TABLE `accelerometer_trusted`(
  `z` double, 
  `timestamp` bigint, 
  `user` string, 
  `y` double, 
  `x` double)
ROW FORMAT SERDE 
  'org.openx.data.jsonserde.JsonSerDe' 
STORED AS INPUTFORMAT 
  'org.apache.hadoop.mapred.TextInputFormat' 
OUTPUTFORMAT 
  'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat'
LOCATION
  's3://thocn-bucket/accelerometer/trusted/'
TBLPROPERTIES (
  'CreatedByJob'='accelerometer_landing_to_trusted_zone', 
  'CreatedByJobRun'='jr_923bb77de58aaa6965a914e66615a142fa0d5559f2a54457f01328699ebe43b2', 
  'classification'='json')