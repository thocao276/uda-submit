import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue import DynamicFrame


def sparkSqlQuery(glueContext, query, mapping, transformation_ctx) -> DynamicFrame:
    for alias, frame in mapping.items():
        frame.toDF().createOrReplaceTempView(alias)
    result = spark.sql(query)
    return DynamicFrame.fromDF(result, glueContext, transformation_ctx)


args = getResolvedOptions(sys.argv, ["JOB_NAME"])
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args["JOB_NAME"], args)

# Script generated for node accelerometer_trusted
accelerometer_trusted_node1 = glueContext.create_dynamic_frame.from_catalog(
    database="project-3",
    table_name="accelerometer_trusted",
    transformation_ctx="accelerometer_trusted_node1",
)

# Script generated for node step_trainer_trusted
step_trainer_trusted_node1697400083324 = glueContext.create_dynamic_frame.from_options(
    format_options={"multiline": True},
    connection_type="s3",
    format="json",
    connection_options={
        "paths": ["s3://thocn-bucket/step-training/trusted/"],
        "recurse": True,
    },
    transformation_ctx="step_trainer_trusted_node1697400083324",
)

# Script generated for node Join
Join_node1697400134815 = Join.apply(
    frame1=step_trainer_trusted_node1697400083324,
    frame2=accelerometer_trusted_node1,
    keys1=["sensorReadingTime"],
    keys2=["timestamp"],
    transformation_ctx="Join_node1697400134815",
)

# Script generated for node SQL Query
SqlQuery980 = """
select sensorReadingTime, serialNumber, distanceFromObject
from myDataSource
"""
SQLQuery_node1697476879924 = sparkSqlQuery(
    glueContext,
    query=SqlQuery980,
    mapping={"myDataSource": Join_node1697400134815},
    transformation_ctx="SQLQuery_node1697476879924",
)

# Script generated for node step_trainer_trusted
step_trainer_trusted_node1697403155910 = glueContext.getSink(
    path="s3://thocn-bucket/machine_learning_curated/",
    connection_type="s3",
    updateBehavior="UPDATE_IN_DATABASE",
    partitionKeys=[],
    enableUpdateCatalog=True,
    transformation_ctx="step_trainer_trusted_node1697403155910",
)
step_trainer_trusted_node1697403155910.setCatalogInfo(
    catalogDatabase="project-3", catalogTableName="machine_learning_curated"
)
step_trainer_trusted_node1697403155910.setFormat("json")
step_trainer_trusted_node1697403155910.writeFrame(SQLQuery_node1697476879924)
job.commit()
