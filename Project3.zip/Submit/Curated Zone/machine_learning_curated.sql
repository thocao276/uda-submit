CREATE EXTERNAL TABLE `machine_learning_curated`(
  `sensorreadingtime` bigint, 
  `serialnumber` string, 
  `distancefromobject` int)
ROW FORMAT SERDE 
  'org.openx.data.jsonserde.JsonSerDe' 
STORED AS INPUTFORMAT 
  'org.apache.hadoop.mapred.TextInputFormat' 
OUTPUTFORMAT 
  'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat'
LOCATION
  's3://thocn-bucket/machine_learning_curated/'
TBLPROPERTIES (
  'CreatedByJob'='machine_learning_curated', 
  'CreatedByJobRun'='jr_e79a2c3ced93d4bc7ed649571fb0f37d2596cf70acc05c004441308eb43471b2', 
  'classification'='json')