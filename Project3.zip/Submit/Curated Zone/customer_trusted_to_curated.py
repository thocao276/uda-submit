import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.dynamicframe import DynamicFrame
from pyspark.sql import functions as SqlFuncs

args = getResolvedOptions(sys.argv, ["JOB_NAME"])
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args["JOB_NAME"], args)

# Script generated for node Customer_trusted
Customer_trusted_node1 = glueContext.create_dynamic_frame.from_options(
    format_options={"multiline": True},
    connection_type="s3",
    format="json",
    connection_options={"paths": ["s3://thocn-bucket/customer/trusted/"]},
    transformation_ctx="Customer_trusted_node1",
)

# Script generated for node accelerometer_trusted
accelerometer_trusted_node1697463877329 = glueContext.create_dynamic_frame.from_options(
    format_options={"multiline": True},
    connection_type="s3",
    format="json",
    connection_options={"paths": ["s3://thocn-bucket/accelerometer/trusted/"]},
    transformation_ctx="accelerometer_trusted_node1697463877329",
)

# Script generated for node Join
Join_node1697465779090 = Join.apply(
    frame1=Customer_trusted_node1,
    frame2=accelerometer_trusted_node1697463877329,
    keys1=["email"],
    keys2=["user"],
    transformation_ctx="Join_node1697465779090",
)

# Script generated for node Select Fields
SelectFields_node1697467503594 = SelectFields.apply(
    frame=Join_node1697465779090,
    paths=[
        "serialNumber",
        "phone",
        "shareWithPublicAsOfDate",
        "birthDay",
        "registrationDate",
        "shareWithResearchAsOfDate",
        "customerName",
        "shareWithFriendsAsOfDate",
        "email",
        "lastUpdateDate",
    ],
    transformation_ctx="SelectFields_node1697467503594",
)

# Script generated for node Drop Duplicates
DropDuplicates_node1697465791323 = DynamicFrame.fromDF(
    SelectFields_node1697467503594.toDF().dropDuplicates(),
    glueContext,
    "DropDuplicates_node1697465791323",
)

# Script generated for node customer_curated
customer_curated_node2 = glueContext.getSink(
    path="s3://thocn-bucket/customer/curated/",
    connection_type="s3",
    updateBehavior="UPDATE_IN_DATABASE",
    partitionKeys=[],
    enableUpdateCatalog=True,
    transformation_ctx="customer_curated_node2",
)
customer_curated_node2.setCatalogInfo(
    catalogDatabase="project-3", catalogTableName="customer_curated"
)
customer_curated_node2.setFormat("json")
customer_curated_node2.writeFrame(DropDuplicates_node1697465791323)
job.commit()
