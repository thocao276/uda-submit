import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.dynamicframe import DynamicFrame
from awsglue import DynamicFrame
from pyspark.sql import functions as SqlFuncs


def sparkSqlQuery(glueContext, query, mapping, transformation_ctx) -> DynamicFrame:
    for alias, frame in mapping.items():
        frame.toDF().createOrReplaceTempView(alias)
    result = spark.sql(query)
    return DynamicFrame.fromDF(result, glueContext, transformation_ctx)


args = getResolvedOptions(sys.argv, ["JOB_NAME"])
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args["JOB_NAME"], args)

# Script generated for node customer_curated
customer_curated_node1697474616088 = glueContext.create_dynamic_frame.from_catalog(
    database="project-3",
    table_name="customers_curated",
    transformation_ctx="customer_curated_node1697474616088",
)

# Script generated for node step_trainer_landing
step_trainer_landing_node1697400083324 = glueContext.create_dynamic_frame.from_options(
    format_options={"multiline": True},
    connection_type="s3",
    format="json",
    connection_options={
        "paths": ["s3://thocn-bucket/step-training/landing/"],
        "recurse": True,
    },
    transformation_ctx="step_trainer_landing_node1697400083324",
)

# Script generated for node Join
step_trainer_landing_node1697400083324DF = step_trainer_landing_node1697400083324.toDF()
customer_curated_node1697474616088DF = customer_curated_node1697474616088.toDF()
Join_node1697400134815 = DynamicFrame.fromDF(
    step_trainer_landing_node1697400083324DF.join(
        customer_curated_node1697474616088DF,
        (
            step_trainer_landing_node1697400083324DF["serialNumber"]
            == customer_curated_node1697474616088DF["serialnumber"]
        ),
        "left",
    ),
    glueContext,
    "Join_node1697400134815",
)

# Script generated for node SQL Query
SqlQuery838 = """
select sensorReadingTime, serialNumber, distanceFromObject
from myDataSource
"""
SQLQuery_node1697475155480 = sparkSqlQuery(
    glueContext,
    query=SqlQuery838,
    mapping={"myDataSource": Join_node1697400134815},
    transformation_ctx="SQLQuery_node1697475155480",
)

# Script generated for node Drop Duplicates
DropDuplicates_node1697476391453 = DynamicFrame.fromDF(
    SQLQuery_node1697475155480.toDF().dropDuplicates(),
    glueContext,
    "DropDuplicates_node1697476391453",
)

# Script generated for node step_trainer_trusted
step_trainer_trusted_node1697403155910 = glueContext.getSink(
    path="s3://thocn-bucket/step-training/trusted/",
    connection_type="s3",
    updateBehavior="UPDATE_IN_DATABASE",
    partitionKeys=[],
    enableUpdateCatalog=True,
    transformation_ctx="step_trainer_trusted_node1697403155910",
)
step_trainer_trusted_node1697403155910.setCatalogInfo(
    catalogDatabase="project-3", catalogTableName="step_trainer_trusted"
)
step_trainer_trusted_node1697403155910.setFormat("json")
step_trainer_trusted_node1697403155910.writeFrame(DropDuplicates_node1697476391453)
job.commit()
