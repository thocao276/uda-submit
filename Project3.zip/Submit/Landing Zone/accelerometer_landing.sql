CREATE EXTERNAL TABLE `accelerometer_landing`(
  `user` string, 
  `timestamp` bigint, 
  `x` float, 
  `y` float, 
  `z` float)
ROW FORMAT SERDE 
  'org.openx.data.jsonserde.JsonSerDe' 
STORED AS INPUTFORMAT 
  'org.apache.hadoop.mapred.TextInputFormat' 
OUTPUTFORMAT 
  'org.apache.hadoop.hive.ql.io.IgnoreKeyTextOutputFormat'
LOCATION
  's3://thocn-bucket/accelerometer/landing'
TBLPROPERTIES (
  'has_encrypted_data'='false', 
  'transient_lastDdlTime'='1697275898')