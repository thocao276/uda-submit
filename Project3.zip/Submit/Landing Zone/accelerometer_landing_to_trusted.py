import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job

args = getResolvedOptions(sys.argv, ["JOB_NAME"])
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args["JOB_NAME"], args)

# Script generated for node accelerometer_landing
accelerometer_landing_node1 = glueContext.create_dynamic_frame.from_options(
    format_options={"multiline": False},
    connection_type="s3",
    format="json",
    connection_options={"paths": ["s3://thocn-bucket/accelerometer/landing/"]},
    transformation_ctx="accelerometer_landing_node1",
)

# Script generated for node customer_trusted
customer_trusted_node1697406890760 = glueContext.create_dynamic_frame.from_options(
    format_options={"multiline": True},
    connection_type="s3",
    format="json",
    connection_options={
        "paths": ["s3://thocn-bucket/customer/trusted/"],
        "recurse": True,
    },
    transformation_ctx="customer_trusted_node1697406890760",
)

# Script generated for node Join
Join_node1697406986840 = Join.apply(
    frame1=accelerometer_landing_node1,
    frame2=customer_trusted_node1697406890760,
    keys1=["user"],
    keys2=["email"],
    transformation_ctx="Join_node1697406986840",
)

# Script generated for node Select Fields
SelectFields_node1697471560826 = SelectFields.apply(
    frame=Join_node1697406986840,
    paths=["user", "timestamp", "x", "y", "z"],
    transformation_ctx="SelectFields_node1697471560826",
)

# Script generated for node accelerometer_trusted
accelerometer_trusted_node1697407083347 = glueContext.getSink(
    path="s3://thocn-bucket/accelerometer/trusted/",
    connection_type="s3",
    updateBehavior="UPDATE_IN_DATABASE",
    partitionKeys=[],
    enableUpdateCatalog=True,
    transformation_ctx="accelerometer_trusted_node1697407083347",
)
accelerometer_trusted_node1697407083347.setCatalogInfo(
    catalogDatabase="project-3", catalogTableName="accelerometer_trusted"
)
accelerometer_trusted_node1697407083347.setFormat("json")
accelerometer_trusted_node1697407083347.writeFrame(SelectFields_node1697471560826)
job.commit()
